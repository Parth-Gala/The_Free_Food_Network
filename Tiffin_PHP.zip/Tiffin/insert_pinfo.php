<?php

$conn = mysqli_connect("localhost", "root", "", "sfmsdb");
        

if ($conn->connect_error){
    die("Connection Failed: " . $conn->connect_error);
}

$name=$_GET["p_name"];
$phone=$_GET["p_phone"];
$email=$_GET["p_email"];
$pass=$_GET["p_password"];

$command = mysqli_query($conn, "INSERT INTO p_info(p_name, p_email, p_phone , p_password) VALUES ('$name','$email','$phone','$pass')");
//$command = $conn->prepare("INSERT INTO p_info(p_username, p_name, p_phone, p_email, p_password) VALUES (?,?,?,?,?)");
//$command->bind_param("isi",$_GET["p_username"],$_GET["p_name"],$_GET["p_phone"],$_GET["p_email"],$_GET["p_password"]);
//$command->execute();

echo "done";



        
        
