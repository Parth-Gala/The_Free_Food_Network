<?php

$conn = mysqli_connect("localhost", "root", "", "sfmsdb");
        

if ($conn->connect_error){
    die("Connection Failed: " . $conn->connect_error);
}

$name=$_GET["p_name"];
$phone=$_GET["p_phone"];
$email=$_GET["p_email"];
$pass=$_GET["p_password"];
//
//$command = mysqli_query($conn, "INSERT INTO cust(c_name, c_email, c_phone , c_password) VALUES ('$name','$email','$phone','$pass')");
$command = $conn->prepare("INSERT INTO cust(c_name, c_email, c_phone , c_password) VALUES (?,?,?,?)");
$command->bind_param("ssss",$name,$email,$phone,$pass);
$command->execute();

echo "Inserted";