<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
$conn = mysqli_connect("localhost", "root", "", "sfmsdb");
$selectPrdouct = $conn->prepare("SELECT prod_name, prod_exp, prod_type, prod_quant FROM p_prod");
$selectPrdouct->execute();
//$sqlCommand->bind_param("isi", $sqlCommand);

$productResult = $selectPrdouct->get_result();

$product = array();

while($row=$productResult->fetch_assoc()){
    array_push($product,$row);
}
echo json_encode($product);