package com.example.tiffin

data class CustomerModel(
    var cName: String? = null,
    var cEmail: String? = null,
    var cPh: String? = null,
    var cPass: String? = null
)