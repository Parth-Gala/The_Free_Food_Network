package com.example.tiffin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val b1 = findViewById(R.id.buttonprov) as Button
        val b2 = findViewById(R.id.buttoncust) as Button

        b1.setOnClickListener{
            setContentView(R.layout.activity_main2)
            val bt1 = findViewById(R.id.buttonlog) as Button

            bt1.setOnClickListener{

                var url:String="http://127.0.0.1/insert_pinfo.php?p_username=" +"&p_name=" + "&p_phone=" + "&p_email=" +"&p_password="

                var rg: RequestQueue = Volley.newRequestQueue(this@MainActivity)

                var jos = JsonObjectRequest(Request.Method.GET,url,null, Response.Listener { response ->
                    Toast.makeText(this, "Record Added", Toast.LENGTH_LONG).show()
                }, Response.ErrorListener { error->
                })
                rg.add(jos)
            }
        }

        b2.setOnClickListener {
            setContentView(R.layout.activity_main3)
        }
    }
}