package com.example.tiffin

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.tiffin.databinding.ActivityMainBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton


class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    lateinit var toggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        process()
    }

    fun process(){
        setContentView(R.layout.home_page_02)
        //popupnav()
        val b1 = findViewById(R.id.buttoncust) as Button
        val b2 = findViewById(R.id.buttonprov) as Button

        b1.setOnClickListener{
            setContentView(R.layout.sign_in)
            //back()
            val hom = findViewById(R.id.back1) as FloatingActionButton
            hom.setOnClickListener {
                process()
            }
            lateinit var t1: TextView
            t1 =findViewById(R.id.mainhead)
            t1.text = "Sign In : Customer"
            val bc1 = findViewById(R.id.reguser) as Button
            bc1.setOnClickListener {
                setContentView(R.layout.customer_signup)
                val hom = findViewById(R.id.back1) as FloatingActionButton
                hom.setOnClickListener {
                    process()
                }
                lateinit var tc1: TextView
                tc1 = findViewById(R.id.titlehead)
                tc1.text = "Customer"
                insert("insert_cust")
            }
        }

        b2.setOnClickListener {
            setContentView(R.layout.sign_in)
            val hom = findViewById(R.id.back1) as FloatingActionButton
            hom.setOnClickListener {
                process()
            }
            lateinit var t1: TextView
            t1 =findViewById(R.id.mainhead)
            t1.text = "Sign In : Provider"
            val bp1 = findViewById(R.id.reguser) as Button
            bp1.setOnClickListener {
                setContentView(R.layout.customer_signup)
                val hom = findViewById(R.id.back1) as FloatingActionButton
                hom.setOnClickListener {
                    process()
                }
                lateinit var tp1: TextView
                tp1 = findViewById(R.id.titlehead)
                tp1.text = "Provider"
                insert("insert_pinfo")
            }
        }
    }

    fun insert(m : String){
        val bt1 = findViewById(R.id.submitlog) as Button
        val name = findViewById(R.id.p_name) as EditText
        val email = findViewById(R.id.p_email) as EditText
        val ph = findViewById(R.id.p_contact) as EditText
        val pass = findViewById(R.id.p_password) as EditText
        lateinit var tp1: TextView
        tp1 = findViewById(R.id.titlehead)
        bt1.setOnClickListener{

            var serverURL:String="https://10.0.2.2/"+m+".php?&p_name=" +name.text.toString()+ "&p_email=" +email.text.toString()+ "&p_phone=" +ph.text.toString()+ "&p_password=" +pass.text.toString()
            print(serverURL)
            var requestQ: RequestQueue = Volley.newRequestQueue(this@MainActivity)

            var jos = JsonObjectRequest(Request.Method.GET,serverURL,null, Response.Listener { response ->
                Toast.makeText(this, "Record Added", Toast.LENGTH_LONG).show()
            }, Response.ErrorListener { error-> tp1.text = error.message
            })
            requestQ.add(jos)
//            var stringRequest =  StringRequest( Request.Method.GET, serverURL,
//                    Response.Listener {
//
//                    }, Response.ErrorListener {
//
//                })
        }
    }

    fun popupnav(){
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setContentView(R.layout.home_page_02)

        binding.apply {
            toggle=ActionBarDrawerToggle(this@MainActivity, drawerLayout,R.string.open,R.string.close)
            drawerLayout.addDrawerListener(toggle)
            toggle.syncState()
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            navView.setNavigationItemSelectedListener {
                when(it.itemId){
                    R.id.firstItem->{
                        Toast.makeText(this@MainActivity, "First Item Selected", Toast.LENGTH_SHORT).show()
                    }
                    R.id.secondItem->{
                        Toast.makeText(this@MainActivity, "Second Item Selected", Toast.LENGTH_SHORT).show()
                    }
                    R.id.thirdItem->{
                        Toast.makeText(this@MainActivity, "Third Item Selected", Toast.LENGTH_SHORT).show()
                    }
                }
                true
            }
        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (toggle.onOptionsItemSelected(item)){
            true
        }
        return super.onOptionsItemSelected(item)
    }
}

