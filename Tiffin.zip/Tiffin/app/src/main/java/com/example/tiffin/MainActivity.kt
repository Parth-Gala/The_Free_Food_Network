package com.example.tiffin

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.tiffin.databinding.ActivityMainBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    lateinit var toggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        process()
    }

    fun process(){
        setContentView(R.layout.home_page_02)
        //popupnav()
        val b1 = findViewById(R.id.buttoncust) as Button
        val b2 = findViewById(R.id.buttonprov) as Button

        b1.setOnClickListener{
            setContentView(R.layout.sign_in)
            //back()
            val hom = findViewById(R.id.back1) as FloatingActionButton
            hom.setOnClickListener {
                process()
            }
            lateinit var t1: TextView
            t1 = findViewById(R.id.mainhead)
            t1.text = "Sign In : Customer"
            val bc1 = findViewById(R.id.reguser) as Button
            bc1.setOnClickListener {
                setContentView(R.layout.customer_signup)
                val hom = findViewById(R.id.back1) as FloatingActionButton
                hom.setOnClickListener {
                    process()
                }
                lateinit var tc1: TextView
                tc1 = findViewById(R.id.titlehead)
                tc1.text = "Customer"
            }
            val tc2 = findViewById(R.id.log) as Button
            tc2.setOnClickListener {
                setContentView(R.layout.customer_filter_provider)
                val hom = findViewById(R.id.back1) as FloatingActionButton
                hom.setOnClickListener {
                    process()
                }
            }
        }

        b2.setOnClickListener {
            setContentView(R.layout.sign_in)
            val hom = findViewById(R.id.back1) as FloatingActionButton
            hom.setOnClickListener {
                process()
            }
            lateinit var t1: TextView
            t1 =findViewById(R.id.mainhead)
            t1.text = "Sign In : Provider"
            val bp1 = findViewById(R.id.reguser) as Button
            bp1.setOnClickListener {
                setContentView(R.layout.customer_signup)
                val hom = findViewById(R.id.back1) as FloatingActionButton
                hom.setOnClickListener {
                    process()
                }
                lateinit var tp1: TextView
                tp1 = findViewById(R.id.titlehead)
                tp1.text = "Provider"
            }
            val tp2 = findViewById(R.id.log) as Button
            tp2.setOnClickListener {
                setContentView(R.layout.provider_provides_details)
                val hom = findViewById(R.id.back1) as FloatingActionButton
                hom.setOnClickListener {
                    process()
                }
            }
        }
    }

//    fun insert(m : String){
//        val bt1 = findViewById(R.id.submitlog) as Button
//        val name = findViewById(R.id.p_name) as EditText
//        val email = findViewById(R.id.p_email) as EditText
//        val ph = findViewById(R.id.p_contact) as EditText
//        val pass = findViewById(R.id.p_password) as EditText
//        val dbRef: DatabaseReference = FirebaseDatabase.getInstance().getReference(m)
//
//        bt1.setOnClickListener{
//            if(email.text.toString().isEmpty()){
//                email.error = "Please Enter Email"
//            }
//            val empID = dbRef.push().key!!
//            val customer = CustomerModel(name.text.toString(), email.text.toString(), ph.text.toString(), pass.text.toString())
//            dbRef.child(empID).setValue(customer)
//                .addOnCompleteListener {
//                    Toast.makeText(this, "Data inserted successfully", Toast.LENGTH_LONG).show()
//                }.addOnFailureListener {err->
//                    Toast.makeText(this, "Error ${err.message}", Toast.LENGTH_LONG).show()
//                }
//            }
//        }
//    }
}

