<?php

$conn = mysqli_connect("localhost", "root", "", "sfmsdb");
        

if ($conn->connect_error){
    die("Connection Failed: " . $conn->connect_error);
}

$name=$_GET["prod_name"];
$exp=$_GET["prod_exp"];
$type=$_GET["prod_type"];
$quant=$_GET["prod_quant"];

$command = mysqli_query($conn, "INSERT INTO p_prod(prod_name, prod_exp, prod_type, prod_quant) VALUES ('$name','$exp','$type','$quant')");
//$command = $conn->prepare("INSERT INTO p_prod(prod_name, prod_exp, prod_type, prod_quant) VALUES (?,?,?,?,?)");
//$command->bind_param("isi",$_GET["prod_name"],$_GET["prod_exp"],$_GET["prod_type"],$_GET["prod_quant"];
//$command->execute();

echo "done";

